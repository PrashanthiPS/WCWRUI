//var HtmlReporter = require('protractor-beautiful-reporter');
var Spec = require('./Spec.json');
exports.config = {
		  
		  seleniumAddress: 'http://localhost:4444/wd/hub',


		 

		  
		  capabilities: {
		    browserName: 'firefox'
		  },

		 

		   'specs': [Spec.addNewRole],

		 
		   jasmineNodeOpts: {
		        showColors: true,
		        defaultTimeoutInterval: 120000,
		        includeStackTrace : true,
		        isVerbose : true,
		       // print: function () {}
		    },
		  
		 
		  
		};


