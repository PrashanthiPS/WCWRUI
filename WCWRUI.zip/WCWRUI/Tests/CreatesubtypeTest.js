var createSubtype = require('../Pages/deleteUser');
var testcasedata = require('../Testdata/data.json');
const EC = protractor.ExpectedConditions;





it('CreateSubtypeTest - It should add Case subtype ', function(){
	   
	  createSubtype.addSubType.click();
	  browser.sleep(3000);
	  createSubtype.subType.click();
	  browser.sleep(3000);
	  createSubtype.saveButton.click();
	  browser.sleep(3000);

 });