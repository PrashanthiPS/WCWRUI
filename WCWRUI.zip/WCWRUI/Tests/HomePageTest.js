var homePage = require('../Pages/homePage');
var testdata = require('../Testdata/data.json');
const EC = protractor.ExpectedConditions;


  describe('WCWRUI Homepage', function () {
	

  it('HomePageTest - It should navigate to WCWR home page!', function () {

	browser.ignoreSynchronization = true;
	browser.waitForAngularEnabled(false);
    browser.driver.manage().window().maximize();
    browser.get(testdata.environment);
    browser.sleep(6000);
    
	homePage.userName.sendKeys(testdata.Username);
	browser.sleep(3000);
	homePage.password.sendKeys(testdata.Password);
	browser.sleep(3000);
	homePage.signonLink.click();
	 //browser.sleep(20000);
	 //element(by.linkText("Allow")).click();
	 browser.sleep(30000);


     //Read titile
    //expect(browser.getTitle()).toEqual("WCWRUI");

      });
  
  /* it('HomePageTest - It should Add New Role!', function(){
	  
	  //browser.ignoreSynchronization = false;
	  
	  homePage.clickOnUserRole.click();
	  browser.sleep(3000);
	  homePage.createAssociation.click();
	  browser.sleep(3000);
	  homePage.roleName.sendKeys(testdata.roleName);
	  browser.sleep(3000);
	  homePage.description.sendKeys(testdata.description);
	  browser.sleep(3000);
	  homePage.acquireDocuments.click();
	  browser.sleep(3000);
	  homePage.add.click();
	  
	  //expect(homePage.roleName.Text()).toContain('AAA');
	  
	  
  });
 
    it('HomePageTest - It should add Case Type', function(){
	   
	  homePage.addCaseType.click();
	  browser.sleep(3000);
	  homePage.createCaseType.click();
	  browser.sleep(3000);
	  homePage.clickOnSave.click();
	  browser.sleep(1000);
	  
	  expect(element(by.css('.alert-container')).getText()).toEqual('Title Type cannot be empty');

	    

  it('HomePageTest - It should delete a random Case type Name', function(){
	   
	  homePage.casetypeIcon.click();
	  browser.sleep(3000);
      homePage.lastPage.click();
      browser.sleep(3000);
	//  homePage.subtypeToDelete.click();
	 // browser.sleep(3000);
	  homePage.deleteCaseType.click();
	  browser.sleep(3000);
	  homePage.deleteCasetypeYes.click();
	  browser.sleep(1000);
	  expect(element(by.css('.alert-container')).getText()).toEqual('Type deleted');
       });

	 it('HomePageTest - It should update a random Case sub type Name', function(){
	   
	  homePage.casesubtypessIcon.click();
	  browser.sleep(3000);
      homePage.lastofPage.click();
      browser.sleep(3000);
	  homePage.casesubtypeUpdate.click();
	  browser.sleep(3000);
	  homePage.casesubtypeEnter.sendKeys(testdata.caseupdates);
	  browser.sleep(3000);
      homePage.saveUpdate.click();
      browser.sleep(3000);
      homePage.confirmSaveupdate.click();
      browser.sleep(1000);
	  expect(element(by.css('.alert-container')).getText()).toEqual('Type updated/added');
       }); 
  /*
   it('HomePageTest - It should add Reject Reason', function(){
	   
	  homePage.addRejectReason.click();
	  browser.sleep(3000);
	  homePage.createReason.click();
	  browser.sleep(3000);
	  homePage.clickOnSave.click();
	  browser.sleep(1000);
      expect(element(by.css('.alert-container')).getText()).toEqual('REASON NAME cannot be empty');
   });
	  
   it('HomePageTest - It should add a Reject Reason', function(){
	   
	  homePage.newRejectReason.click();
	  browser.sleep(3000);
	  homePage.writeReason.click();
	  browser.sleep(3000);
	  homePage.reasonName.sendKeys(testdata.reason);
	  homePage.clickSaveButton.click();
	  browser.sleep(3000);
	  homePage.selectConfirm.click();
	  browser.sleep(3000);
	  homePage.confirmSave.click();
	  browser.sleep(1000);
	  expect(element(by.css('.alert-container')).getText()).toEqual('Reject reason updated/added'); 
  }); 


  // update reject reason 

	 it('HomePageTest - It should update a randomReject reason  Name', function(){
	   
	  homePage.rejectReasonIcon.click();
	  browser.sleep(3000);
      
	  homePage.rejectUpdate.click();
	  browser.sleep(3000);
	  homePage.reasonEnter.sendKeys(testdata.caseupdates);
	  browser.sleep(3000);
      homePage.savereasonUpdate.click();
      browser.sleep(3000);
      homePage.confirmreasonupdate.click();
      browser.sleep(1000);
	  expect(element(by.css('.alert-container')).getText()).toEqual('Reject reason updated/added');
       }); 




  it('HomePageTest - It should delete a random  Reason Name', function(){
	   
	  homePage.reasonIcon.click();
	  browser.sleep(3000);
	  homePage.reasonToDelete.click();
	  browser.sleep(3000);
	  homePage.deleteReasonSymbol.click();
	  browser.sleep(3000);
	  homePage.deleteReasonYes.click();
	  browser.sleep(1000);
      expect(element(by.css('.alert-container')).getText()).toEqual('Reject reason deleted');
	  
       });

   it('HomePageTest - It should add Case Subtype', function(){
	   
	  homePage.addSubType.click();
	  browser.sleep(3000);
	  homePage.createSubType.click();
	  browser.sleep(3000);
	  homePage.saveButton.click();
	  browser.sleep(1000);
      expect(element(by.css('.alert-container')).getText()).toEqual('Type updated/added');
   });  
	   
   it('HomePageTest - It should add a Subtype Name', function(){
	   
	  homePage.newCaseSubtype.click();
	  browser.sleep(3000);
	  homePage.writeSubtype.click();
	  browser.sleep(3000);
	  homePage.subtypeName.sendKeys(testdata.subtype);
	  homePage.clickSave.click();
	  browser.sleep(3000);
	  homePage.clickConfirm.click();
	  browser.sleep(3000);
	  homePage.confirmOnSave.click();
	  browser.sleep(1000);
      expect(element(by.css('.alert-container')).getText()).toEqual('Case Sub Type deleted');

	   });

   */ // new code !!
      it('HomePageTest - It should delete a Subtype', function() {
	
	  homePage.subTypeIcon.click();
	  browser.sleep(3000);
	  homePage.lastPagesubtype.click();
	  browser.sleep(3000);
	  homePage.enterSubtype.click();
      browser.sleep(3000);
	 
	  homePage.deleteOption.click();
	  browser.sleep(3000);
	  homePage.confirmDelete.click();
	  browser.sleep(3000); 
      expect(element(by.css('.alert-container')).getText()).toEqual('Case Sub Type deleted');
   }); 

/*
     it('HomePageTest - It should delete a random  Subtype Name', function(){
	   
	  homePage.subIcon.click();
	  browser.sleep(3000);
	  homePage.subtypeToDelete.click();
	  browser.sleep(3000);
	  homePage.deleteSymbol.click();
	  browser.sleep(3000);
	  homePage.deleteYes.click();
	  browser.sleep(1000);
	  expect(element(by.css('.alert-container')).getText()).toEqual('Case Sub Type deleted')
       });


	 
	 // delete user (active /inactive)
	/*	 
	it('HomePageTest - It should delete a random User Name', function(){
	   
	  homePage.usersTab.click();
	  browser.sleep(5000);
	  homePage.findUser.click();
	  browser.sleep(3000);
	  homePage.checkBox.click();
	  browser.sleep(3000);
      homePage.updateUser.click();
	  browser.sleep(3000);
      homePage.mailConfirm.click();
	  browser.sleep(3000);
	  
       });

 // delete user (active /inactive)
		 
 it('HomePageTest - It should add adminUser', function(){
	   
	  homePage.userIcon.click();
	  browser.sleep(5000);
	  homePage.createButton.click();
	  browser.sleep(3000);
	  homePage.createAdmin.click();
	  browser.sleep(3000);
      homePage.firstName.sendKeys(testdata.name);
	  browser.sleep(3000);
      homePage.lastName.sendKeys(testdata.lasttname);
	  browser.sleep(3000);
	  homePage.enterEmail.sendKeys(testdata.mailid);
      browser.sleep(3000);
      homePage.loginId.sendKeys(testdata.lognid);
      browser.sleep(3000);
      homePage.selectCalendar.click();
      browser.sleep(3000);
      homePage.datePicker.click();
      browser.sleep(3000);
     // homePage.prevMonth.click();
     // browser.sleep(3000);
      homePage.createButtontwo.click();
      browser.sleep(3000);
      homePage.confirmEmailButton.click();
      browser.sleep(3000);
       });   
		 
	it('HomePageTest - It should add casemanager', function(){
	   
	  homePage.usersIcon.click();
	  browser.sleep(5000);
	  homePage.createnewButton.click();
	  browser.sleep(3000);
      homePage.createCasemanager.click();
	  browser.sleep(3000);
      homePage.firstNamebutton.sendKeys(testdata.firstNamebutton);
	  browser.sleep(3000);
      homePage.lastNamebutton.sendKeys(testdata.lastNamebutton);
	  browser.sleep(3000);
	  homePage.emailButton.sendKeys(testdata.mailid);
      browser.sleep(3000);
      homePage.loginIdButton.sendKeys(testdata.loginIdButton);
      browser.sleep(3000);
      homePage.selectCalendarButton.click();
      browser.sleep(3000);
      homePage.datePickersafebday.click();
      browser.sleep(3000);
      homePage.selectrolesButton.click();
      browser.sleep(3000);
      homePage.searchrole.sendKeys(testdata.searchRole);
      browser.sleep(3000);
      homePage.selectAll.click();
      browser.sleep(3000);
     // homePage.selectAll.click();
      //browser.sleep(3000);
      homePage.doneButton.click();
      browser.sleep(3000);
      homePage.courtsTab.click();
      browser.sleep(3000);
      homePage.checkBox.click();
      browser.sleep(3000);
      homePage.courtDonebutton.click();
      browser.sleep(3000);
      homePage.superCasetype.click();
      browser.sleep(3000);
      homePage.selectCheckbox.click();
      browser.sleep(3000);
      homePage.selectionDone.click();
      browser.sleep(3000);
      homePage.createcasemanagerButton.click();
      browser.sleep(3000);
      homePage.confirmpopButton.click();
      browser.sleep(3000);

*/







});