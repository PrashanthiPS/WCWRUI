
class HomePage {
    constructor() {

        //Login:
    	this.userName = element(by.id('username'));
        this.password = element(by.id('password'));
        this.signonLink = element(by.linkText('Sign On'));
        
     /*   //Add New Role
        this.clickOnUserRole = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[2]/a"));
        this.createAssociation = element(by.buttonText('Create Association'));
        this.roleName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[1]/app-search-template[1]/div/div/input"));
        this.description = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[1]/app-search-template[2]/div/div/input"));
        this.acquireDocuments = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[1]/app-search-template[5]/div/div/label/input"));
        this.add = element(by.xpath("/html/body/app-root/div/div/div[2]/app-roles/div/div/div[2]/div/div[2]/app-search-template/div[2]/div/button/span"));
      
        //Add Case Type without Case Type Title.
        this.addCaseType = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[7]/a"));
        this.createCaseType = element(by.buttonText('Create Case Type'));
        this.clickOnSave = element(by.buttonText('SAVE')); 
       
 
     // delete a random case type
        this.casetypeIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[7]/a")); 
        this.lastPage = element(by.xpath("/html/body/app-root/div/div/div[2]/app-type/div/div/div[1]/app-type-list/div[2]/app-flexgrid-template/div/div/ngb-pagination/ul/li[13]/a"));
        //this.reasonToDelete = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteCaseType = element(by.xpath("/html/body/app-root/div/div/div[2]/app-type/div/div/div[1]/app-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[2]/div/i/span"));
        this.deleteCasetypeYes = element(by.buttonText('DELETE')); 
        
       */ 
        // Update a random case sub type

        this.casesubtypessIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a")); 
        this.lastofPage = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/ngb-pagination/ul/li[13]/a"));
        this.casesubtypeUpdate = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.casesubtypeEnter = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[2]/div/div/app-sub-type-add-edit/app-search-template[2]/div/div/input"));
        this.saveUpdate = element(by.buttonText('SAVE'));
        this.confirmSaveupdate = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]")); 
/*

       //add Reject reason without reason name 
        this.addRejectReason =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a"));
        this.createReason = element(by.buttonText('Create Reason'));
        this.clickOnSave = element(by.buttonText('SAVE')); 
        



       //Add Reject reason
        this.newRejectReason =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a"));
        this.writeReason = element(by.buttonText('Create Reason'));
        this.reasonName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-reject-reasons/div/div/div[2]/div/div/app-reject-reason-add-edit/app-search-template[2]/div/div/input"));
        this.clickSaveButton = element(by.buttonText('SAVE'));
        this.selectConfirm = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"))
        this.confirmSave = element(by.buttonText('YES')); 
        

       // delete a random reject reason
        this.reasonIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a")); 
        this.reasonToDelete = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteReasonSymbol = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteReasonYes = element(by.buttonText('DELETE')); 
        

// update a random reason name 
        this.rejectReasonIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[6]/a")); 
       // this.lastofPage = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/ngb-pagination/ul/li[13]/a"));
        this.rejectUpdate = element(by.xpath("/html/body/app-root/div/div/div[2]/app-reject-reasons/div/div/div[1]/app-reject-reason-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.reasonEnter = element(by.xpath("/html/body/app-root/div/div/div[2]/app-reject-reasons/div/div/div[2]/div/div/app-reject-reason-add-edit/app-search-template[2]/div/div/input"));
        this.savereasonUpdate = element(by.buttonText('SAVE'));
        this.confirmreasonupdate = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]")); 



        //add Subtype without entering subtype name 
        this.addSubType =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a"));
        this.createSubType = element(by.buttonText('Create Case Subtype'));
        this.saveButton = element(by.buttonText('SAVE')); 
       
        //Add Case Subtype

        this.newCaseSubtype =element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a"));
        this.writeSubtype = element(by.buttonText('Create Case Subtype'));
        this.subtypeName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[2]/div/div/app-sub-type-add-edit/app-search-template[2]/div/div/input"));
        this.clickSave = element(by.buttonText('SAVE'));
        this.clickConfirm = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"))
        this.confirmOnSave = element(by.buttonText('YES'));
       
     */
    
       // delete an existing case subtype

        this.subTypeIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a"));
        this.lastPagesubtype = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/ngb-pagination/ul/li[13]/a"));
        this.enterSubtype = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
       
        this.deleteOption= element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[2]/div/i/span"));
        this.confirmDelete = element(by.buttonText('DELETE'));
      
/*
      // delete a random subtype 
        this.subIcon= element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[8]/a")); 
        this.subtypeToDelete = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]"));
        this.deleteSymbol = element(by.xpath("/html/body/app-root/div/div/div[2]/app-sub-type/div/div/div[1]/app-sub-type-list/div[2]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[2]/div/i/span"));
        this.deleteYes = element(by.buttonText('DELETE'));
        expect(element(by.css('.alert-container')).getText()).toEqual('Case Sub Type deleted');

      //delete a random user
       	 
	 // delete user (active /inactive)
		 
		this.usersTab = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[1]/a"));
		this.findUser = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[3]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[2]/div[1]/div/span")); 
		//this.clickUser = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[3]/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[2]/div[1]/div[3]/div[6]"));
		this.checkBox = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[1]/div/div/label/input"));
		this.updateUser = element(by.buttonText('UPDATE'));
		this.mailConfirm = element(by.buttonText('Send Mail'));
		
		 //Add new user (admin)
	     this.userIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[1]/a"));
         this.createButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[1]/div[1]/button"));
         this.createAdmin = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[1]/div[2]/button[1]"));
         this.firstName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[2]/div[1]/div/input"));
         this.lastName = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[2]/div[2]/div/input"));
         this.enterEmail = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[3]/div/div/input"));
         this.loginId = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[4]/div/div/input"));
         this.selectCalendar = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[5]/div/div/form/div/div/button/i"));
       //  this.prevMonth = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[5]/div/div/form/div/div/ngb-datepicker/div[1]/ngb-datepicker-navigation/button[1]/span"));
         this.datePicker = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[5]/div/div/form/div/div/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[2]/div[5]/div"));
         this.createButtontwo = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[2]/app-search-template/div[2]/div/button/span"));
         this.confirmEmailButton = element(by.buttonText('Send Mail'));
         expect(element(by.css('.alert-container')).getText()).toEqual('The following User with Login ID APM094 has been successfully Created');

         //Add new user (case manager)

        this.usersIcon = element(by.xpath("/html/body/app-root/div/div/div[1]/ul[1]/li[1]/a"));
        this.createnewButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[1]/div[1]/button"));
        this.createCasemanager =element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[1]/div[1]/div[2]/button[2]"));
        this.firstNamebutton =element (by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[2]/div[1]/div/input"));
        this.lastNamebutton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[2]/div[2]/div/input"));
        this.emailButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[3]/div/div/input"));
        this.loginIdButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[4]/div/div/input"));
        this.selectCalendarButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[5]/div/div/form/div/div/button/i"));
        this.datePickersafebday = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[5]/div/div/form/div/div/ngb-datepicker/div[2]/div/ngb-datepicker-month-view/div[2]/div[5]/div"));
        this.selectrolesButton = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[6]/div[1]/div/div[1]/bento-multiselect-overlay/div/div/button"));
        this.searchrole = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[6]/div[1]/div/div[1]/bento-multiselect-overlay/div/div/div/div[1]/bento-multiselect-list/div/input"));
        this.selectAll = element (by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[6]/div[1]/div/div[1]/bento-multiselect-overlay/div/div/div/div[1]/bento-multiselect-list/bento-list-core/div[1]/div/div[2]/i"));
        this.doneButton = element (by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[6]/div[1]/div/div[1]/bento-multiselect-overlay/div/div/div/div[1]/div/button"));
        this.courtsTab = element(by.xpath ("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[6]/div[2]/div/div/button"));
        this.checkBox = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[2]/div/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[8]/div/div/div/div/div/bento-checkbox/input"));
        this.courtDonebutton = element (by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"));
        this.superCasetype = element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[1]/app-search-template[7]/div[2]/div/div/button"));
        this.selectCheckbox = element (by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[2]/div/app-flexgrid-template/div/div/wj-flex-grid/div[1]/div[8]/div/div/div/div/div/bento-checkbox/input"));
        this.selectionDone = element(by.xpath("/html/body/ngb-modal-window/div/div/app-modal-window/div[3]/div/button[1]"));
        this.createcasemanagerButton =element(by.xpath("/html/body/app-root/div/div/div[2]/app-users/div/div/div[2]/div/app-create-user/div[2]/app-search-template/div[2]/div/button"));
        this.confirmpopButton = element(by.buttonText('Send Mail'));
        expect(element(by.css('.alert-container')).getText()).toEqual('The following User with Login ID APM094 has been successfully Created');

*/
        
    }
}

module.exports = new HomePage();